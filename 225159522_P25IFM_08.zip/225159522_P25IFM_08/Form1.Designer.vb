﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmStore
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnUpdate = New System.Windows.Forms.Button()
        Me.BtnCalc = New System.Windows.Forms.Button()
        Me.btnSetup = New System.Windows.Forms.Button()
        Me.grdstore = New UJGrid.UJGrid()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtstores = New System.Windows.Forms.TextBox()
        Me.txtDays = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'btnUpdate
        '
        Me.btnUpdate.Location = New System.Drawing.Point(301, 165)
        Me.btnUpdate.Name = "btnUpdate"
        Me.btnUpdate.Size = New System.Drawing.Size(138, 69)
        Me.btnUpdate.TabIndex = 1
        Me.btnUpdate.Text = "Update Num Of eggs"
        Me.btnUpdate.UseVisualStyleBackColor = True
        '
        'BtnCalc
        '
        Me.BtnCalc.Location = New System.Drawing.Point(301, 85)
        Me.BtnCalc.Name = "BtnCalc"
        Me.BtnCalc.Size = New System.Drawing.Size(138, 53)
        Me.BtnCalc.TabIndex = 3
        Me.BtnCalc.Text = "Calculate"
        Me.BtnCalc.UseVisualStyleBackColor = True
        '
        'btnSetup
        '
        Me.btnSetup.Location = New System.Drawing.Point(301, 23)
        Me.btnSetup.Name = "btnSetup"
        Me.btnSetup.Size = New System.Drawing.Size(138, 40)
        Me.btnSetup.TabIndex = 5
        Me.btnSetup.Text = "Input"
        Me.btnSetup.UseVisualStyleBackColor = True
        '
        'grdstore
        '
        Me.grdstore.FixedCols = 1
        Me.grdstore.FixedRows = 1
        Me.grdstore.Location = New System.Drawing.Point(13, 241)
        Me.grdstore.Margin = New System.Windows.Forms.Padding(4)
        Me.grdstore.Name = "grdstore"
        Me.grdstore.Scrollbars = System.Windows.Forms.ScrollBars.Both
        Me.grdstore.Size = New System.Drawing.Size(774, 185)
        Me.grdstore.TabIndex = 7
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(469, 90)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(119, 17)
        Me.Label1.TabIndex = 9
        Me.Label1.Text = "Number of Sotres"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(469, 46)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(108, 17)
        Me.Label2.TabIndex = 11
        Me.Label2.Text = "Number of days"
        '
        'txtstores
        '
        Me.txtstores.Location = New System.Drawing.Point(652, 85)
        Me.txtstores.Name = "txtstores"
        Me.txtstores.Size = New System.Drawing.Size(100, 22)
        Me.txtstores.TabIndex = 13
        '
        'txtDays
        '
        Me.txtDays.Location = New System.Drawing.Point(652, 41)
        Me.txtDays.Name = "txtDays"
        Me.txtDays.Size = New System.Drawing.Size(100, 22)
        Me.txtDays.TabIndex = 15
        '
        'FrmStore
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.txtDays)
        Me.Controls.Add(Me.txtstores)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.grdstore)
        Me.Controls.Add(Me.btnSetup)
        Me.Controls.Add(Me.BtnCalc)
        Me.Controls.Add(Me.btnUpdate)
        Me.Name = "FrmStore"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnUpdate As Button
    Friend WithEvents BtnCalc As Button
    Friend WithEvents btnSetup As Button
    Friend WithEvents grdstore As UJGrid.UJGrid
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents txtstores As TextBox
    Friend WithEvents txtDays As TextBox
End Class
