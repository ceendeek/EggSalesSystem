﻿' **************************************************************************** 
' Surname, Initials: Mpofu, CA
' Student Number: 225159522
' Practical: P25IFM-08 
' Class name: frmEaster 
' **************************************************************************** 
Option Strict On
Option Explicit On
Public Class FrmStore
    Private NumberOfStores As Integer
    Private NumberOfDays As Integer
    Private StoreDay(,) As Integer
    Private TotalStore() As Integer
    Private TotalDay() As Integer
    Private AverageStore() As Double
    Private AverageDay() As Integer

    Private Sub Placestore(ByVal r As Integer, ByVal c As Integer, ByVal t As String)
        grdstore.Row = r
        grdstore.Col = c
        grdstore.Text = t
    End Sub

    Private Sub FrmStore_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Placestore(0, 0, "Days")
    End Sub

    Private Sub btnSetup_Click(sender As Object, e As EventArgs) Handles btnSetup.Click
        'Get Number of days from user
        NumberOfDays = CInt(InputBox("Enter Number of days where eggs were sold"))
        txtDays.Text = CStr(NumberOfDays)

        'Get Number of stores from user
        NumberOfStores = CInt(InputBox("Enter the number of stores that sold eggs"))
        txtstores.Text = CStr(NumberOfStores)

        'Set grid rows and columns
        grdstore.Rows = NumberOfDays + 3
        grdstore.Cols = NumberOfStores + 3

        ' Initialize StoreDay array
        ReDim StoreDay(NumberOfDays, NumberOfStores)

        'label days
        For count As Integer = 1 To NumberOfDays
            Placestore(count, 0, "Day " & count)
        Next

        'label stores
        For counter As Integer = 1 To NumberOfStores
            Placestore(0, counter, "Store " & counter)
        Next

        'Get egg sales data per day per store
        For count As Integer = 1 To NumberOfDays
            For counter As Integer = 1 To NumberOfStores
                StoreDay(count, counter) = CInt(InputBox("Enter the number of eggs sold on Day " & count & " at Store " & counter))
                Placestore(count, counter, CStr(StoreDay(count, counter)))
            Next
        Next

        ' Set up total and average column headers
        Placestore(0, NumberOfStores + 1, "Total")
        Placestore(0, NumberOfStores + 2, "Average")
    End Sub

    Private Sub BtnCalc_Click(sender As Object, e As EventArgs) Handles BtnCalc.Click
        CalculateAverageAndTotals()
    End Sub

    Private Sub CalculateAverageAndTotals()
        ReDim TotalDay(NumberOfDays)
        ReDim TotalStore(NumberOfStores)
        ReDim AverageDay(NumberOfDays)
        ReDim AverageStore(NumberOfStores)

        ' Calculate totals and averages for days
        For count As Integer = 1 To NumberOfDays
            TotalDay(count) = 0
            For counter As Integer = 1 To NumberOfStores
                TotalDay(count) += StoreDay(count, counter)
            Next
            AverageDay(count) = CInt(TotalDay(count) / NumberOfStores)
            Placestore(count, NumberOfStores + 1, CStr(TotalDay(count)))
            Placestore(count, NumberOfStores + 2, CStr(AverageDay(count)))
        Next

        ' Calculate totals and averages for stores
        For counter As Integer = 1 To NumberOfStores
            TotalStore(counter) = 0
            For count As Integer = 1 To NumberOfDays
                TotalStore(counter) += StoreDay(count, counter)
            Next
            AverageStore(counter) = CInt(TotalStore(counter) / NumberOfDays)
            Placestore(NumberOfDays + 1, counter, CStr(TotalStore(counter)))
            Placestore(NumberOfDays + 2, counter, CStr(AverageStore(counter)))
        Next

        Placestore(NumberOfDays + 1, 0, "Total")
        Placestore(NumberOfDays + 2, 0, "Average")
    End Sub

    Private Function UpdateEggSales(ByVal NewEggSales As Integer, ByVal currentSales As Integer) As Integer
        Dim AddNum As Integer = NewEggSales + currentSales
        Return AddNum
    End Function

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        Dim day As Integer = CInt(InputBox("Which day do you want to edit between 1- " & NumberOfDays))
        Dim store As Integer = CInt(InputBox("which store do you want to edit between 1- " & NumberOfStores))
        Dim NewEggSales As Integer = CInt(InputBox("how many eggs do you want to add"))
        Dim currentSales As Integer = StoreDay(day, store)
        Dim updatedSales As Integer = UpdateEggSales(NewEggSales, currentSales)
        StoreDay(day, store) = updatedSales ' Update StoreDay array
        Placestore(day, store, CStr(updatedSales))
        CalculateAverageAndTotals() ' Recalculate totals and averages
    End Sub


End Class

